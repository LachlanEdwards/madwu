var set = {
    title_y: 186
};

var elements = {
    dining_menu: document.querySelectorAll('#dining-menu .panel'),
    private_dine: document.querySelectorAll('#private-dining .feature-item'),
    venue_function: document.querySelectorAll('#venue-functions .feature-item'),
    gift_card: document.querySelectorAll('#gift-card .form-group'),
    events: document.querySelectorAll('#events .event-item'),
    faq: document.querySelectorAll('#faq .panel'),
    contact: document.querySelectorAll('#contact .form-group')
};

var sections = [
    document.querySelector('#dining-menu'),
    document.querySelector('#private-dining'),
    document.querySelector('#venue-functions'),
    document.querySelector('#gift-card'),
    document.querySelector('#events'),
    document.querySelector('#faq'),
    document.querySelector('#contact')
];

var navlinks = [
    document.querySelector('.md-nav .list-item#dining-menu'),
    document.querySelector('.md-nav .list-item#private-dining'),
    document.querySelector('.md-nav .list-item#venue-functions'),
    document.querySelector('.md-nav .list-item#gift-card'),
    document.querySelector('.md-nav .list-item#events'),
    document.querySelector('.md-nav .list-item#faq'),
    document.querySelector('.md-nav .list-item#contact')
];

function addActiveClass() {
    for (var i = 0; i < sections.length; i++) {
        if (sections[i].getBoundingClientRect().top <= 0 && sections[i].getBoundingClientRect().bottom >= 0) {
            if (!navlinks[i].classList.toString().includes("active")) {
                navlinks[i].classList += " active";
            }
        } else {
            navlinks[i].classList = "list-item";
        }
    }
}

function detectActiveSection() {
    for (var i = 0; i < sections.length; i++) {
        console.log(sections[i]);
        if (sections[i].getBoundingClientRect().top <= 0) {
            console.log(navlinks[i]);
            addActiveClass(navlinks[i]);
        }
    }
}

function addAnimationClass(elementArray) {
    for (var i = 0; i < elementArray.length; i++) {
        var delay = i * 500 + 500;
        var element = elementArray[i];
        var element_y = element.getBoundingClientRect().top;
        if (element_y <= window.innerHeight && !element.classList.contains('animated')) {
            element.classList += ' animated fadeInLeft';
        }
    }
}


var scroll_position = {
    dining_menu: function () {
        addAnimationClass(elements.dining_menu);
    },
    private_dine: function () {
        addAnimationClass(elements.private_dine);
    },
    venue_function: function () {
        addAnimationClass(elements.venue_function);
    },
    gift_card: function () {
        addAnimationClass(elements.gift_card);
    },
    events: function () {
        addAnimationClass(elements.events);
    },
    faq: function () {
        addAnimationClass(elements.faq);
    },
    contact: function () {
        addAnimationClass(elements.contact);
    }
}

function executeAllAnimations() {
    scroll_position.dining_menu();
    scroll_position.private_dine();
    scroll_position.venue_function();
    scroll_position.gift_card();
    scroll_position.events();
    scroll_position.faq();
    scroll_position.contact();
}

function execute() {
    executeAllAnimations();
    addActiveClass();
};

window.addEventListener('scroll', execute);
